namespace ESBFrameWorkDemo {
    
    
    [Microsoft.XLANGs.BaseTypes.SchemaReference(@"ESBFrameWorkDemo.RcvMsg", typeof(global::ESBFrameWorkDemo.RcvMsg))]
    [Microsoft.XLANGs.BaseTypes.SchemaReference(@"ESBFrameWorkDemo.CanMsg", typeof(global::ESBFrameWorkDemo.CanMsg))]
    public sealed class BuildCanMsg : global::Microsoft.XLANGs.BaseTypes.TransformBase {
        
        private const string _strMap = @"<?xml version=""1.0"" encoding=""UTF-16""?>
<xsl:stylesheet xmlns:xsl=""http://www.w3.org/1999/XSL/Transform"" xmlns:msxsl=""urn:schemas-microsoft-com:xslt"" xmlns:var=""http://schemas.microsoft.com/BizTalk/2003/var"" exclude-result-prefixes=""msxsl var"" version=""1.0"">
  <xsl:output omit-xml-declaration=""yes"" method=""xml"" version=""1.0"" />
  <xsl:template match=""/"">
    <xsl:apply-templates select=""/Rcv"" />
  </xsl:template>
  <xsl:template match=""/Rcv"">
    <CanMsg>
      <Info>
        <StatusCode>
          <xsl:value-of select=""Info/StatusCode/text()"" />
        </StatusCode>
        <StatusDesc>
          <xsl:value-of select=""Info/StatusDesc/text()"" />
        </StatusDesc>
        <Metadata>
          <Key>
            <xsl:value-of select=""Info/Metadata/Key/text()"" />
          </Key>
          <Value>
            <xsl:value-of select=""Info/Metadata/Value/text()"" />
          </Value>
          <xsl:value-of select=""Info/Metadata/text()"" />
        </Metadata>
        <xsl:value-of select=""Info/text()"" />
      </Info>
      <SellerInfo>
        <Metadata>
          <Key>
            <xsl:value-of select=""SellerInfo/Metadata/Key/text()"" />
          </Key>
          <Value>
            <xsl:value-of select=""SellerInfo/Metadata/Value/text()"" />
          </Value>
          <xsl:value-of select=""SellerInfo/Metadata/text()"" />
        </Metadata>
        <xsl:value-of select=""SellerInfo/text()"" />
      </SellerInfo>
      <Error>
        <Metadata>
          <Key>
            <xsl:value-of select=""Error/Metadata/Key/text()"" />
          </Key>
          <Value>
            <xsl:value-of select=""Error/Metadata/Value/text()"" />
          </Value>
          <xsl:value-of select=""Error/Metadata/text()"" />
        </Metadata>
        <xsl:value-of select=""Error/text()"" />
      </Error>
    </CanMsg>
  </xsl:template>
</xsl:stylesheet>";
        
        private const int _useXSLTransform = 0;
        
        private const string _strArgList = @"<ExtensionObjects />";
        
        private const string _strSrcSchemasList0 = @"ESBFrameWorkDemo.RcvMsg";
        
        private const global::ESBFrameWorkDemo.RcvMsg _srcSchemaTypeReference0 = null;
        
        private const string _strTrgSchemasList0 = @"ESBFrameWorkDemo.CanMsg";
        
        private const global::ESBFrameWorkDemo.CanMsg _trgSchemaTypeReference0 = null;
        
        public override string XmlContent {
            get {
                return _strMap;
            }
        }
        
        public override int UseXSLTransform {
            get {
                return _useXSLTransform;
            }
        }
        
        public override string XsltArgumentListContent {
            get {
                return _strArgList;
            }
        }
        
        public override string[] SourceSchemas {
            get {
                string[] _SrcSchemas = new string [1];
                _SrcSchemas[0] = @"ESBFrameWorkDemo.RcvMsg";
                return _SrcSchemas;
            }
        }
        
        public override string[] TargetSchemas {
            get {
                string[] _TrgSchemas = new string [1];
                _TrgSchemas[0] = @"ESBFrameWorkDemo.CanMsg";
                return _TrgSchemas;
            }
        }
    }
}
